﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorListaGenerica
{
    public static class Funciones
    {
        public static T? Buscar<T>(this IEnumerable<T> lista, Predicate<T> funcion)
        {
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    return elemento;
                }
            }
            return default;
        }

        public static IEnumerable<T> Filtrar<T>(this IEnumerable<T> lista, Predicate<T> funcion)
        {
            IList<T> nuevaLista = new List<T>();
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    nuevaLista.Add(elemento);
                }
            }
            return nuevaLista;
        }

        public static T1? Reducir<T1, T2>(this IEnumerable<T2> lista, Func<T1?, T2, T1> funcion)
        {
            T1? valor = default(T1);
            foreach (T2 elemento in lista)
            {
                valor = funcion(valor, elemento);
            }
            return valor;
        }

        public static T1? Invertir<T1, T2>(this IEnumerable<T2> lista, Func<T1?, T2, T1> funcion)
        {
            T1? valor = default(T1);
            foreach (T2 elemento in lista.Reverse())
            {
                valor = funcion(valor, elemento);
            }
            return valor;
        }

        public static IEnumerable<Q> Map<T, Q>(this IEnumerable<T> enumerable, Func<T, Q> func)
        {
            IList<Q> lista = new List<Q>();
            foreach (T actual in enumerable)
                lista.Add(func(actual));
            return lista;
        }

        public static void ForEach<T>(this IEnumerable<T> enumerable, Action<T> action)
        {
            foreach (T item in enumerable)
            {
                action(item);
            }
        }
    }
}
