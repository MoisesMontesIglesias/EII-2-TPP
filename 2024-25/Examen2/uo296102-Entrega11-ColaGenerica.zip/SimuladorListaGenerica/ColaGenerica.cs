﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorListaGenerica
{
    public class ColaGenerica<T>
    {

        public int numeroElementos
        {
            get
            {
                lock (lista)
                {
                    return lista.GetNumElems();
                }
            }
        }
        private ListaGenerica<T> lista;

        public ColaGenerica() 
        {
            lista = new ListaGenerica<T>();
        }

        public int getNumeroElementos()
        {
            lock (lista)
            {
                return lista.GetNumElems();
            }
        }

        public bool EstaVacia()
        {
            lock (lista)
            {
                if (numeroElementos == 0)
                {
                    return true;
                }
                return false;
            }
        }

        public void Anadir(T elemento)
        {
            lock (lista)
            {
                lista.Anadir(elemento);
            }
        }

        public T Extraer()
        {
            lock (lista)
            {
                T elementoExtraido = lista.GetNodoAt(0).valor;
                lista.Borrar(elementoExtraido);
                return elementoExtraido;
            }
        }


        public T PrimerElemento()
        {
            lock (lista)
            {
                return lista.GetNodoAt(0).valor;
            }
        }
    }
}
