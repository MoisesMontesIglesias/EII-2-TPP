﻿using System;
using System.Collections;
using System.Drawing;
using System.Text;

namespace SimuladorListaGenerica
{
    public class ListaGenerica<T> : IEnumerable<T>
    {
        private int numElementos;
        private Nodo? head;
        private IteradorDeLista iterador;

        public ListaGenerica() {
            numElementos = 0;
            head = null;
        }
        public ListaGenerica(List<T> lista)
        {
            foreach (T item in lista)
            {
                this.Anadir(item);
            }
        }

        public void Anadir(T valor)
        {
            Nodo? nuevoNodo = new Nodo(valor);
            if (head == null)
            {
                head = nuevoNodo;
            }
            else
            {
                Nodo? posUltimo = GetNodoAt(numElementos - 1);
                posUltimo.Siguiente = nuevoNodo;
            }
            numElementos++;
        }

        public bool Borrar(T valor)
        {
            if (head == null)
            {
                return false;
            }
            else if ((head.valor == null && valor == null) || (head.valor != null && head.valor.Equals(valor)))
            {
                head = head.Siguiente;
                numElementos--;
                return true;
            }
            else
            {
                Nodo actual = head;
                while (actual.Siguiente != null && !((actual.Siguiente.valor == null && valor == null) 
                    || (actual.Siguiente.valor != null && actual.Siguiente.valor.Equals(valor))))
                {
                    actual = actual.Siguiente;
                }
                if (actual.Siguiente == null)
                {
                    return false;
                }
                else
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    numElementos--;
                    return true;
                }
            }
        }

        public int GetPosicionNodo(T valor)
        {
            Nodo? actual = head;
            int posicion = 0;
            for (int i = 0; i < numElementos; i++)
            {
                if ((actual.valor == null && valor == null) || (actual.valor != null && actual.valor.Equals(valor)))
                {
                    return posicion;
                }
                else
                {
                    actual = actual?.Siguiente;
                    posicion++;
                }
            }
            return -1;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Nodo? actual = head;
            while(actual != null)
            {
                yield return actual.valor;
                actual = actual?.Siguiente;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public int GetNumElems()
        {
            return numElementos;
        }
        public Nodo? GetNodoAt(int contador)
        {
            if (contador < 0 || contador > numElementos)
            {
                throw new ArgumentOutOfRangeException("Valor fuera de rango");
            }
            Nodo? actual = head;
            for (int i = 0; i < contador; i++)
            {
                actual = actual?.Siguiente;
            }
            return actual;
        }

        public bool Contiene(T valor)
        {
            Nodo? actual = head;
            while (actual != null)
            {
                if (Object.Equals(actual.valor, valor))
                {
                    return true;
                }
                actual = actual?.Siguiente;
            }
            return false;
        }
        override public String ToString()
        {
            if (GetNumElems() == 0)
            {
                return "Lista vacía";
            }
            Nodo? actual = head;
            StringBuilder sb = new StringBuilder();
            while (actual != null)
            {
                if (actual.valor == null)
                {
                    sb.Append("null");
                }
                else
                {
                    sb.Append(actual.valor.ToString());
                }
                if (actual.Siguiente != null)
                {
                    sb.Append(" -> ");
                }
                actual = actual.Siguiente;
            }
            return sb.ToString();
        }

        public class Nodo
        {
            public T valor { get; set; }
            public Nodo? Siguiente { get; set; }
            public Nodo(T valor)
            {
                this.valor = valor;
                this.Siguiente = null;
            }
        }

        public class IteradorDeLista : IEnumerator<T>
        {

            private int posicion;
            private ListaGenerica<T> lista;

            public IteradorDeLista(ListaGenerica<T> lista)
            {
                this.lista = lista;
                posicion = 0;
            }

            public T Current()
            {
                return lista.GetNodoAt(posicion).valor;
            }

            object IEnumerator.Current => throw new NotImplementedException();

            T IEnumerator<T>.Current => throw new NotImplementedException();

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                posicion++;
                if (posicion > lista.GetNumElems())
                {
                    return false;
                }
                return true;
            }

            public void Reset()
            {
                posicion = -1;
            }
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
    }
}
