﻿using SimuladorListaGenerica;
namespace Main
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}