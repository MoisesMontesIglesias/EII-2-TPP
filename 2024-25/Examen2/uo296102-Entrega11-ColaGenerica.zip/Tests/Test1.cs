﻿using Modelo;
using SimuladorListaGenerica;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;

namespace Tests
{
    [TestClass]
    public sealed class Test1
    {
        [TestClass]
        public sealed class PruebasTest
        {
            [TestMethod]
            public void PruebasAñadirPersona()
            {
                ListaGenerica<Persona> list = new ListaGenerica<Persona>();
                Persona persona1 = new Persona("Alvaro", "Alvarez", "1234", 2);
                Persona persona2 = new Persona("Juan", "Alvarez", "1234", 1);
                Persona persona3 = new Persona("Maria", "Jimenez", "2334", 2);
                list.Anadir(persona1);
                Assert.AreEqual(1, list.GetNumElems());
                list.Anadir(persona2);
                Assert.AreEqual(2, list.GetNumElems());
                list.Anadir(persona2);
                Assert.AreEqual(3, list.GetNumElems());
                list.Anadir(persona3);
                Assert.AreEqual(4, list.GetNumElems());
                list.Anadir(null);
                Assert.AreEqual(5, list.GetNumElems());
            }

            [TestMethod]
            public void PruebasBorrarPersona()
            {
                ListaGenerica<Persona> list = new ListaGenerica<Persona>();
                Persona persona1 = new Persona("Alvaro", "Alvarez", "1234", 2);
                Persona persona2 = new Persona("Juan", "Alvarez", "1234", 1);
                Persona persona3 = new Persona("Maria", "Jimenez", "2334", 2);
                list.Anadir(persona1);
                list.Anadir(persona2);
                list.Anadir(persona2);
                list.Anadir(persona3);
                list.Anadir(null);
                Assert.AreEqual(5, list.GetNumElems());
                Assert.AreEqual(true, list.Borrar(persona1));
                Assert.AreEqual(4, list.GetNumElems());
                Assert.AreEqual(true, list.Borrar(persona2));
                Assert.AreEqual(3, list.GetNumElems());
                Assert.AreEqual(false, list.Borrar(persona1));
                Assert.AreEqual(3, list.GetNumElems());
            }

            [TestMethod]
            public void PruebasContienePersona()
            {
                ListaGenerica<Persona> list = new ListaGenerica<Persona>();
                Persona persona1 = new Persona("Alvaro", "Alvarez", "1234", 2);
                Persona persona2 = new Persona("Juan", "Alvarez", "1234", 2);
                Persona persona3 = new Persona("Maria", "Jimenez", "2334", 34);
                list.Anadir(persona1);
                list.Anadir(persona2);
                list.Anadir(persona2);
                list.Anadir(persona3);
                list.Anadir(null);
                Assert.AreEqual(true, list.Contiene(persona1));
                Assert.AreEqual(true, list.Contiene(persona2));
                Assert.AreEqual(true, list.Borrar(persona1));
                Assert.AreEqual(4, list.GetNumElems());
                Assert.AreEqual(false, list.Contiene(persona1));
            }

            [TestMethod]
            public void PruebasAñadirPosicionToStringInt()
            {
                ListaGenerica<int> lista = new ListaGenerica<int>();
                lista.Anadir(1);
                lista.Anadir(2);
                lista.Anadir(3);
                Assert.AreEqual(3, lista.GetNumElems());
                Assert.AreEqual("1 -> 2 -> 3", lista.ToString());
                Assert.IsTrue(lista.Borrar(2));
                Assert.AreEqual(2, lista.GetNumElems());
                Assert.AreEqual("1 -> 3", lista.ToString());
                Assert.IsFalse(lista.Borrar(4));
                Assert.AreEqual(2, lista.GetNumElems());
                lista.Anadir(2);
                Assert.AreEqual("1 -> 3 -> 2", lista.ToString());
                Assert.AreEqual(2, lista.GetPosicionNodo(2));
                Assert.AreEqual(0, lista.GetPosicionNodo(1));
                Assert.AreEqual(1, lista.GetPosicionNodo(3));
                Assert.AreEqual(-1, lista.GetPosicionNodo(4));
                Assert.IsTrue(lista.Contiene(2));
                Assert.IsFalse(lista.Contiene(4));
            }


            [TestMethod]
            public void PruebasBorrarPosicionToStringString()
            {
                ListaGenerica<string> lista = new ListaGenerica<string>();
                Assert.AreEqual("Lista vacía", lista.ToString());
                lista.Anadir("Hola");
                lista.Anadir(null);
                lista.Anadir("Buenos Dias");
                Assert.AreEqual(1, lista.GetPosicionNodo(null));
                Assert.IsTrue(lista.Borrar(null));
                lista.Anadir(null);
                Assert.AreEqual(3, lista.GetNumElems());
                Assert.AreEqual("Hola -> Buenos Dias -> null", lista.ToString());
                Assert.AreEqual(2, lista.GetPosicionNodo(null));
            }

            [TestMethod]
            public void TestBuscar()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                Angulo[] angulos = Factoria.CrearAngulos();
                var resultado = Funciones.Buscar(personas, p => p.Nif == "23476293R");
                var resultado2 = Funciones.Buscar(personas, p => p.Nif == "00000000Z");
                var resultado3 = Funciones.Buscar(angulos, a => Math.Abs(a.Radianes - (90 * Math.PI / 180)) < 0.0001);
                Assert.IsNotNull(resultado);
                Assert.AreEqual("Pepe", resultado.Nombre);
                Assert.IsNull(resultado2);
                Assert.IsNotNull(resultado3);
                Assert.AreEqual(Math.PI / 2, resultado3.Radianes);
                //Prueba de los métodos con mi lista
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>();
                Persona persona1 = new Persona("Alvaro", "Alvarez", "1234", 2);
                Persona persona2 = new Persona("Juan", "Alvarez", "1234", 2);
                Persona persona3 = new Persona("Maria", "Jimenez", "2334", 34);
                listaPersonas.Anadir(persona1);
                listaPersonas.Anadir(persona2);
                listaPersonas.Anadir(persona3);
                var resultadoLista = listaPersonas.Buscar(p => p.Nif == "2334");
                Assert.AreEqual("Maria", resultadoLista?.Nombre);
            }

            [TestMethod]
            public void TestFiltrar()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                Angulo[] angulos = Factoria.CrearAngulos();
                var resultado = Funciones.Filtrar(personas, p => p.Edad > 18);
                var resultado2 = Funciones.Filtrar(angulos, a => a.Radianes > Math.PI);
                Assert.AreEqual(5, resultado.Count());
                Assert.IsTrue(resultado.All(p => p.Edad > 18));
                Assert.AreEqual(180, resultado2.Count());
                Assert.IsTrue(resultado2.All(a => a.Radianes > Math.PI));
                Assert.IsTrue(resultado.All(p => p.Edad > 18));
                //Prueba de los métodos con mi lista
                ListaGenerica<Angulo> listaAngulos = new ListaGenerica<Angulo>(Factoria.ListasAngulos());
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>(Factoria.ListasPersonas());
                resultado = listaPersonas.Filtrar(p => p.Edad > 18);
                resultado2 = listaAngulos.Filtrar(a => a.Radianes > Math.PI);
                Assert.AreEqual(5, resultado.Count());
                Assert.IsTrue(resultado.All(p => p.Edad > 18));
                Assert.AreEqual(180, resultado2.Count());
                Assert.IsTrue(resultado2.All(a => a.Radianes > Math.PI));
            }

            [TestMethod]
            public void TestReducir()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                Angulo[] angulos = Factoria.CrearAngulos();
                int suma = Funciones.Reducir<int, Persona>(personas, (total, p) => (total) + p.Edad);
                double producto = Funciones.Reducir<double, Angulo>(angulos, (total, a) => (total) * a.Radianes);
                //Prueba de los métodos con mi lista
                ListaGenerica<int> numeros = new ListaGenerica<int>();
                int resultado = numeros.Reducir<int, int>((total, n) => (total) + n);
                Assert.AreEqual(171, suma);
                Assert.IsNotNull(producto);
                Assert.AreEqual(0, resultado);
                ListaGenerica<Angulo> listaAngulos = new ListaGenerica<Angulo>(Factoria.ListasAngulos());
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>(Factoria.ListasPersonas());
                suma = listaPersonas.Reducir<int, Persona>((total, p) => (total) + p.Edad);
                producto = listaAngulos.Reducir<double, Angulo>((total, a) => (total) * a.Radianes);
                numeros = new ListaGenerica<int>();
                resultado = numeros.Reducir<int, int>((total, n) => (total) + n);
                Assert.AreEqual(171, suma);
                Assert.IsNotNull(producto);
                Assert.AreEqual(0, resultado);
            }

            [TestMethod]
            public void TestInvertir()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                Angulo[] angulos = Factoria.CrearAngulos();
                var ultimaPersona = Funciones.Invertir<Persona, Persona>(personas, (actual, p) => p);
                var ultimoAngulo = Funciones.Invertir<Angulo, Angulo>(angulos, (actual, a) => a);
                Assert.IsNotNull(ultimaPersona);
                Assert.AreEqual("María", ultimaPersona.Nombre);
                Assert.IsNotNull(ultimoAngulo);
                Assert.AreEqual(0, ultimoAngulo.Radianes);
                //Prueba de los métodos con mi lista
                ListaGenerica<Angulo> listaAngulos = new ListaGenerica<Angulo>(Factoria.ListasAngulos());
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>(Factoria.ListasPersonas());
                ultimaPersona = Funciones.Invertir<Persona, Persona>(personas, (actual, p) => p);
                ultimoAngulo = Funciones.Invertir<Angulo, Angulo>(angulos, (actual, a) => a);
                Assert.IsNotNull(ultimaPersona);
                Assert.AreEqual("María", ultimaPersona.Nombre);
                Assert.IsNotNull(ultimoAngulo);
                Assert.AreEqual(0, ultimoAngulo.Radianes);
            }

            [TestMethod]
            public void TestMap()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                Angulo[] angulos = Factoria.CrearAngulos();
                var nombres = personas.Map(p => p.Nombre);
                var grados = angulos.Map(a => a.Radianes * 180 / Math.PI);
                Assert.AreEqual(personas.Length, nombres.Count());
                Assert.IsTrue(nombres.Contains("María"));
                Assert.AreEqual(angulos.Length, grados.Count());
                Assert.IsTrue(grados.Contains(90.0));
                //Prueba de los métodos con mi lista
                ListaGenerica<Angulo> listaAngulos = new ListaGenerica<Angulo>(Factoria.ListasAngulos());
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>(Factoria.ListasPersonas());
                nombres = personas.Map(p => p.Nombre);
                grados = angulos.Map(a => a.Radianes * 180 / Math.PI);
                Assert.AreEqual(personas.Length, nombres.Count());
                Assert.IsTrue(nombres.Contains("María"));
                Assert.AreEqual(angulos.Length, grados.Count());
                Assert.IsTrue(grados.Contains(90.0));
            }

            [TestMethod]
            public void TestForEach()
            {
                //Prueba de los métodos sin mi lista
                Persona[] personas = Factoria.CrearPersonas();
                int contador = 0;
                personas.ForEach(p => contador++);
                Assert.AreEqual(personas.Length, contador);
                //Prueba de los métodos con mi lista
                ListaGenerica<Persona> listaPersonas = new ListaGenerica<Persona>(Factoria.ListasPersonas());
                contador = 0;
                listaPersonas.ForEach(p => contador++);
                Assert.AreEqual(personas.Length, contador);
            }
        }
    }
}
