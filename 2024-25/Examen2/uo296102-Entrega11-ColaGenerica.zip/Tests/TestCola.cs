﻿using Modelo;
using SimuladorListaGenerica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    [TestClass]
    public sealed class TestCola
    {
        [TestMethod]
        public void TestEstaVacia()
        {
            ColaGenerica<string> cola = new ColaGenerica<string>();
            Assert.IsTrue(cola.EstaVacia());
            cola.Anadir("elemento");
            Assert.IsFalse(cola.EstaVacia());
            cola.Extraer();
            Assert.IsTrue(cola.EstaVacia());
        }

        [TestMethod]
        public void TestEstaVacia2()
        {
            ColaGenerica<int> cola = new ColaGenerica<int>();
            cola.Anadir(1);
            cola.Anadir(2);
            cola.Anadir(3);
            Assert.AreEqual(1, cola.Extraer());
            Assert.IsFalse(cola.EstaVacia());
            Assert.AreEqual(2, cola.Extraer());
            Assert.IsFalse(cola.EstaVacia());
            Assert.AreEqual(3, cola.Extraer());
            Assert.IsTrue(cola.EstaVacia());
        }

        [TestMethod]
        public void TestAnadirCola()
        {
            ColaGenerica<Persona> cola = new ColaGenerica<Persona>();
            Thread[] hilos = new Thread[10];
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(() =>
                {
                    for (int j = 0; j < 5; j++)
                    {
                        Persona persona = new Persona("Alvaro", "Alvarez", "1234", 2);
                        cola.Anadir(persona);
                        cola.Anadir(null);
                    }
                });
                hilos[i].Start();
            }
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i].Join();
            }
            Assert.AreEqual(100, cola.numeroElementos);
        }

        [TestMethod]
        public void TestExtraerCola()
        {
            ColaGenerica<int> cola = new ColaGenerica<int>();
            for (int i = 0; i < 101; i++)
            {
                cola.Anadir(i);
            }
            Thread[] hilos = new Thread[10];
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(() =>
                {
                    for (int j = 0; j < 10; j++)
                    {
                        cola.Extraer();
                    }
                });
                hilos[i].Start();
            }
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i].Join();
            }
            Assert.AreEqual(1, cola.numeroElementos);
            Assert.AreEqual(100, cola.Extraer());
        }
    }
}
