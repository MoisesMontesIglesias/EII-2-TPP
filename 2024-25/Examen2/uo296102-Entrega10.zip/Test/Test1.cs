﻿using Ejercicio;
using ObligatoriaSesion10;
namespace Test
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var hilos = Utils.GetBitcoinData();
            int limite = 7000;
            var master = new Master(hilos, limite);

            int secuencial = master.AppSecuencial(7000);
            int concurrencia = master.AppConcurrente(7000);

            Assert.AreEqual(secuencial, concurrencia);
        }
    }
}
