﻿using ObligatoriaSesion10;
using System.Diagnostics;
using System.Globalization;
using System.Numerics;

namespace Ejercicio
{
    class Program
    {
        /*
         * This program processes Bitcoin value information obtained from the
         * url https://api.kraken.com/0/public/OHLC?pair=xbteur&interval=5.
         */
        static void Main(string[] args)
        {
            var data = Utils.GetBitcoinData();

            //Console.WriteLine(CultureInfo.CurrentCulture);
            //foreach (var d in data)
            //    Console.WriteLine(d);

            MostrarLinea(Console.Out, "Num Hilos", "Ticks", "Resultado");
            const int maximoHilos = 50;
            Stopwatch stopWatch = new Stopwatch();
            for (int numeroHilos = 1; numeroHilos <= maximoHilos; numeroHilos++)
            {
                Master master = new Master(data, numeroHilos);
                stopWatch.Restart();
                var resultado = master.AppConcurrente(numeroHilos);
                //var resultado = master.AppSecuencial(numeroHilos);
                stopWatch.Stop();
                MostrarLinea(Console.Out, numeroHilos, stopWatch.ElapsedTicks, resultado);
                GC.Collect();
                GC.WaitForFullGCComplete();
            }
        }
        static void MostrarLinea(TextWriter stream, string numHilosCabecera, string ticksCabecera, string resultadoCabecera)
        {
            stream.WriteLine("{0};{1};{2}", numHilosCabecera, ticksCabecera, resultadoCabecera);
        }

        static void MostrarLinea(TextWriter stream, int numHilos, long ticks, double resultado)
        {
            stream.WriteLine("{0};{1:N0};{2:N2}", numHilos, ticks, resultado);
        }
    }
}
