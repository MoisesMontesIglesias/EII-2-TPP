﻿using ObligatoriaSesion10;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio
{
    public class Master
    {
        private BitcoinValueData[] vector;
        private int numeroHilos;

        public Master(BitcoinValueData[] vector, int numeroHilos)
        {
            if (numeroHilos < 1 || numeroHilos > vector.Length)
                throw new ArgumentException("El número de hilos debe ser menor o igual al tamaño del vector");
            this.vector = vector;
            this.numeroHilos = numeroHilos;
        }
        public int AppSecuencial(int valorPrefijado)
        {
            int totalValores = 0;
            foreach (var v in vector)
            {
                if (v.Value > valorPrefijado)
                {
                    totalValores++;
                }
            }
            return totalValores;
        }

        public int AppConcurrente(int valorPrefijado)
        {
            Worker[] workers = new Worker[this.numeroHilos];
            int numElementosPorHilo = this.vector.Length / numeroHilos;
            for (int i = 0; i < this.numeroHilos; i++)
            {
                int indiceDesde = i * numElementosPorHilo;
                int indiceHasta = (i + 1) * numElementosPorHilo - 1;
                if (i == this.numeroHilos - 1)
                {
                    indiceHasta = this.vector.Length - 1;
                }
                workers[i] = new Worker(this.vector, indiceDesde, indiceHasta);
            }
            Thread[] hilos = new Thread[workers.Length];
            for (int i = 0; i < workers.Length; i++)
            {
                int valorActual = i;
                hilos[i] = new Thread(() => workers[valorActual].AppCalcular(valorPrefijado));
                hilos[i].Name = "Worker número: " + (i + 1);
                hilos[i].Priority = ThreadPriority.Normal;
                hilos[i].Start(); 
            }
            foreach (Thread thread in hilos)
            {
                thread.Join();
            }
            int resultado = 0;
            foreach (Worker worker in workers)
                resultado += worker.Resultado;
            return resultado;
        }
    }
}
