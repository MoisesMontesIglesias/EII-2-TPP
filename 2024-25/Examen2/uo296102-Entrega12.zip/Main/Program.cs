﻿using PracticaObligatoria12;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.RegularExpressions;
using static System.Net.Mime.MediaTypeNames;

namespace Main
{
    public class Program
    {
        static void Main(string[] args)
        {
            String texto = ProcesadorTextos.LeerFicheroTexto(@"..\..\..\..\clarin.txt");
            string[] palabras = ProcesadorTextos.DividirEnPalabras(texto);

            //Secuencial 
            Stopwatch sw = new Stopwatch();
            sw.Start();

            Dictionary<string, int> contadorSecuencial = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (string palabra in palabras)
            {
                if (contadorSecuencial.ContainsKey(palabra))
                    contadorSecuencial[palabra]++;
                else
                    contadorSecuencial[palabra] = 1;
            }

            sw.Stop();
            Console.WriteLine($"Tiempo (secuencial): {sw.ElapsedMilliseconds} ms");

            //Paralelo
            sw = new Stopwatch();
            sw.Start();
            ConcurrentDictionary<string, int> contadorParalelo = new ConcurrentDictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            Parallel.ForEach(palabras, palabra =>
            {
                contadorParalelo.AddOrUpdate(palabra, 1, (key, valorAnterior) => valorAnterior + 1);
            });

            sw.Stop();
            Console.WriteLine($"Tiempo (paralelo): {sw.ElapsedMilliseconds} ms");

            // P1: ¿Por qué cree que el beneficio de rendimiento no es muy elevado?
            // Porque ConcurrentDictionary bloquea internamente para que no haya muchos hilos
            // actualizando la misma palabra, que puedan dar lugar a errores a la hora de contar
            // las veces que aparece una palabra.
            //
            // P2: ¿Qué se podría hacer para mejorarlo?
            // Usar un diccionario local por cada hilo, haciendo Parallel.ForEach sobre bloques
            // del array palabras
        }
    }
}
