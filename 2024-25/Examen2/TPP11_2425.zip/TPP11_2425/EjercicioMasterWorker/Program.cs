﻿namespace EjercicioMasterWorker
{
    internal class Program
    {
        /// <summary>
        /// A partir del Master Worker de la entrega obligatoria, prueba las siguientes modificaciones:
        /// -Los workers almacenarán en una lista común "Resultado", los valores que sean superiores a la cantidad buscada.
        ///     - No admitirá duplicados.
        ///     - La lista Resultado la pasa el Master a los workers, por lo que es LA MISMA PARA TODOS LOS WORKERS.
        /// </summary>
        static void Main()
        {
            
        }
    }
}
