﻿using System.Diagnostics;
using System.Numerics;

namespace _02ExclusionMutua
{
    internal class Program
    {


        static short[] vector = CrearVectorAleatorio(20000000, 0, 10);

        public static int aparicionesSecuencial; 

        public static int aparacionesMultihilo;


        private static readonly object _object = new object();

        static void Main()
        {
            ContarSecuencialAparaciones(2);
            ContarSecuencialAparaciones(3);
            Console.WriteLine($"[Secuencial] El número 2 y el 3 aparecen {aparicionesSecuencial} veces.");
            

            Thread[] hilos = new Thread[2];
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(ContarAparicionesNumeroEnVector);
                hilos[i].Start(i + 2);
            }

            foreach (var hilo in hilos)
                hilo.Join();  

            Console.WriteLine($"[Multihilo] El número 2 y el 3 aparecen {aparacionesMultihilo} veces.");

       
            //Toma tiempos de la versión secuencial y la versión multihilo (Material de la sesión anterior)

            //¿Cuál es más rápida? ¿Por qué ocurre?
            //¿Se te ocurre alguna forma de mejorar la versión multihilo?
            //Impleméntala y toma tiempos.
        }

        static void ContarSecuencialAparaciones(short numero)
        {
            for (int i = 0; i < vector.Length; i++)
            {
                if (vector[i] == numero)
                {
                    aparicionesSecuencial++;   
                }
            }
        }

        static void ContarAparicionesNumeroEnVector(object? numero)
        {
            int buscado = (int)numero;
            for (int i = 0; i < vector.Length; i++)
            {
                if (vector[i] == buscado)
                {
                    // Sección crítica de código
                    // ¿Qué hace lock?
                    lock (_object)
                    {
                        aparacionesMultihilo++;
                    }
                    // Como regla básica, es necesario bloquear cualquier operación de escritura.
                    // Incluyendo los casos aparentemente más simples, como el de modificar/incrementar el valor de una variable.
                    // ¡REPASAD EN LA TEORÍA QUÉ OPERACIONES SON!
                }
            }
        }



        public static short[] CrearVectorAleatorio(int numElementos, short menor, short mayor)
        {
            short[] vector = new short[numElementos];
            Random random = new Random();
            for (int i = 0; i < numElementos; i++)
                vector[i] = (short)random.Next(menor, mayor + 1);
            return vector;
        }


    }
}
