﻿namespace _03Interlocked
{

    /// <summary>
    /// Una alternativa más eficiente a lock es el uso de la clase Interlocked (System.Threading)
    /// Realiza asignaciones de forma primitiva.
    /// Métodos más utilizados: Increment, Decrement, CompareExchange, Add.
    /// https://learn.microsoft.com/en-us/dotnet/api/system.threading.interlocked?view=net-8.0
    /// Observa bien con qué tipos pueden utilizarse.
    /// </summary>
    internal class Program
    {
        static int contador = 0;

        static void Incrementar()
        {
            for (int i = 0; i < 100000; i++)
            {
                Interlocked.Increment(ref contador);
            }
        }

        static void Main()
        {
            Thread[] hilos = new Thread[2];
            for(int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(Incrementar);
                hilos[i].Start();
            }

            foreach (var hilo in hilos)
                hilo.Join();

            Console.WriteLine($"Total del contador: {contador}");
        }

        //EJERCICIO: Crear y entender un ejemplo para cada uno de los siguientes métodos de Interlocked:
        //Decrement, Add, Exchange y CompareExchange.

        //EJERCICIO: Impleméntese una versión del presente ejemplo utilizando lock y mídase el rendimiento de ambas versiones.
    }
}
