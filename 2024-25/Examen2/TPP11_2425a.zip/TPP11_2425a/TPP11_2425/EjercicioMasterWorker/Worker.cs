﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioMasterWorker
{
    public class Worker
    {
        private BitcoinValueData[] vector;

        private int indiceDesde, indiceHasta;

        private int resultado;

        internal int Resultado
        {
            get { return this.resultado; }
        }

        internal Worker(BitcoinValueData[] vector, int indiceDesde, int indiceHasta)
        {
            this.vector = vector;
            this.indiceDesde = indiceDesde;
            this.indiceHasta = indiceHasta;
        }

        internal void AppCalcular(int valorLimite, ref List<int> lista, object o)
        {
            this.resultado = 0;
            for (int i = this.indiceDesde; i <= this.indiceHasta; i++)
            {
                if (vector[i].Value > valorLimite)
                {
                    this.resultado++;
                }
            }
            lock (o)
            {
                if (!lista.Contains(this.resultado))
                {
                    lista.Add(this.resultado);
                }
            }
        }
    }
}
