﻿using System.Diagnostics;

namespace EjercicioMasterWorker
{
    internal class Program
    {
        /// <summary>
        /// A partir del Master Worker de la entrega obligatoria, prueba las siguientes modificaciones:
        /// -Los workers almacenarán en una lista común "Resultado", los valores que sean superiores a la cantidad buscada.
        ///     - No admitirá duplicados.
        ///     - La lista Resultado la pasa el Master a los workers, por lo que es LA MISMA PARA TODOS LOS WORKERS.
        /// </summary>
        static void Main(string[] args)
        {
            var data = Utils.GetBitcoinData();

            //Console.WriteLine(CultureInfo.CurrentCulture);
            //foreach (var d in data)
            //    Console.WriteLine(d);

            MostrarLinea(Console.Out, "Num Hilos", "Ticks", "Resultado");
            const int maximoHilos = 50;
            Stopwatch stopWatch = new Stopwatch();
            for (int numeroHilos = 1; numeroHilos <= maximoHilos; numeroHilos++)
            {
                Master master = new Master(data, numeroHilos);
                stopWatch.Restart();
                var resultado = master.AppConcurrente(numeroHilos);
                //var resultado = master.AppSecuencial(numeroHilos);
                stopWatch.Stop();
                MostrarLinea(Console.Out, numeroHilos, stopWatch.ElapsedTicks, resultado);
                GC.Collect();
                GC.WaitForFullGCComplete();
            }
        }
        static void MostrarLinea(TextWriter stream, string numHilosCabecera, string ticksCabecera, string resultadoCabecera)
        {
            stream.WriteLine("{0};{1};{2}", numHilosCabecera, ticksCabecera, resultadoCabecera);
        }

        static void MostrarLinea(TextWriter stream, int numHilos, long ticks, double resultado)
        {
            stream.WriteLine("{0};{1:N0};{2:N2}", numHilos, ticks, resultado);
        }
    }
}
