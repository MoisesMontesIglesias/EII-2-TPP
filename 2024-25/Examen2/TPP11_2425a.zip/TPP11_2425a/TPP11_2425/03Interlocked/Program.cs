﻿using System.Diagnostics;

namespace _03Interlocked
{

    /// <summary>
    /// Una alternativa más eficiente a lock es el uso de la clase Interlocked (System.Threading)
    /// Realiza asignaciones de forma primitiva.
    /// Métodos más utilizados: Increment, Decrement, CompareExchange, Add.
    /// https://learn.microsoft.com/en-us/dotnet/api/system.threading.interlocked?view=net-8.0
    /// Observa bien con qué tipos pueden utilizarse.
    /// </summary>
    internal class Program
    {
        static int contador = 0;
        static readonly object o = new object();
        static void Incrementar()
        {
            for (int i = 0; i < 100000; i++)
            {
                Interlocked.Increment(ref contador);
            }
        }

        static void Main()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            Thread[] hilos = new Thread[2];
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(Incrementar);
                hilos[i].Start();
            }

            foreach (var hilo in hilos)
                hilo.Join();

            Console.WriteLine($"Total del contador: {contador}");
            sw.Stop();
            Console.WriteLine($"Tiempo del Interlock: {sw.ElapsedMilliseconds}");
            contador = 0;
            sw = new Stopwatch();
            sw.Start();
            hilos = new Thread[2];
            for (int i = 0; i < hilos.Length; i++)
            {
                hilos[i] = new Thread(IncrementarLock);
                hilos[i].Start();
            }

            foreach (var hilo in hilos)
                hilo.Join();

            Console.WriteLine($"Total del contador: {contador}");
            sw.Stop();
            Console.WriteLine($"Tiempo del Lock: {sw.ElapsedMilliseconds}");

        }

        //EJERCICIO: Crear y entender un ejemplo para cada uno de los siguientes métodos de Interlocked:
        //Decrement, Add, Exchange y CompareExchange.
        static void Decrementar()
        {
            for (int i = 0; i < 100000; i++)
            {
                Interlocked.Decrement(ref contador);
            }
        }

        static void Anadir()
        {
            for (int i = 0; i < 100000; i++)
            {
                Interlocked.Add(ref contador, i);
            }
        }

        static void Cambiar()
        {
            int contadorLocal = 0;
            for (int i = 0; i < 100000; i++)
            {
                contadorLocal += i;
                Interlocked.Exchange(ref contador, contadorLocal); //Asigna contadorLocal a contador
            }
        }

        static void CambiarSi()
        {
            for (int i = 0; i < 100000; i++)
            {
                Interlocked.CompareExchange(ref contador, 1, 0); //Compara el contador con 0 y si es igual
                // Lo cambia a 1.
            }
        }
        //EJERCICIO: Impleméntese una versión del presente ejemplo utilizando lock y mídase el rendimiento de ambas versiones.
        static void IncrementarLock()
        {
            int contadorLocal = 0;
            for (int i = 0; i < 100000; i++)
            {
                contadorLocal++;
            }
            lock (o)
            {
                contador += contadorLocal;
            }
        }
    }
}
