﻿using System.Diagnostics;
using System.Numerics;

namespace _02ExclusionMutua
{
    internal class Program
    {


        static short[] vector = CrearVectorAleatorio(20000000, 0, 10);

        public static int aparicionesSecuencial; 

        public static int aparacionesMultihilo;


        private static readonly object _object = new object(); // --> readonly: solo lectura --> static: porque se debe trabajar los hilos sobre el mismo

        static void Main()
        {
            Stopwatch stopwatch = new Stopwatch();
            //MostrarLinea(Console.Out, "Num Hilos", "Ticks", "Resultado");
            stopwatch.Restart();
            ContarSecuencialAparaciones(2);
            ContarSecuencialAparaciones(3);
            Console.WriteLine($"[Secuencial] El número 2 y el 3 aparecen {aparicionesSecuencial} veces.");
            Console.WriteLine($"[Secuencial] El número 2 y el 3 aparecen {stopwatch.ElapsedMilliseconds} veces.");
            //MostrarLinea(Console.Out, 2, stopwatch.ElapsedTicks, aparicionesSecuencial);

            stopwatch.Stop();
            //MostrarLinea(Console.Out, "Num Hilos", "Ticks", "Resultado");
            stopwatch.Restart();


            Thread[] hilos = new Thread[2];
            for (int i = 0; i < hilos.Length; i++)
            {
                int valor = i + 2;
                hilos[i] = new Thread(() => ContarLock(valor));
                hilos[i].Start();
            }

            foreach (var hilo in hilos)
                hilo.Join();



            stopwatch.Stop();
            Console.WriteLine($"[Multihilo] El número 2 y el 3 aparecen {aparacionesMultihilo} veces.");
            Console.WriteLine($"[Multihilo] El número 2 y el 3 aparecen {stopwatch.ElapsedMilliseconds} veces.");
            //MostrarLinea(Console.Out, 2, stopwatch.ElapsedTicks, aparacionesMultihilo);


            //Toma tiempos de la versión secuencial y la versión multihilo (Material de la sesión anterior)

            //¿Cuál es más rápida? ¿Por qué ocurre?
            // Es más rápida la secuencial, ya que el lock genera mucho tiempo de espera
            //¿Se te ocurre alguna forma de mejorar la versión multihilo?
            // Separando el trabajo sobre una parte diferente, contando cada hilo con su variable local
            // Y solo al final sumará su conteo con un único lock.
            //Impleméntala y toma tiempos.

        }

        static void ContarMultihiloOptimizado(int numero1, int numero2)
        {
            int numHilos = Environment.ProcessorCount; // Usamos tantos hilos como núcleos de la CPU
            Thread[] hilos = new Thread[numHilos];

            int tamañoParte = vector.Length / numHilos;

            for (int i = 0; i < numHilos; i++)
            {
                int inicio = i * tamañoParte;
                int fin = (i == numHilos - 1) ? vector.Length : inicio + tamañoParte; // Último hilo coge todo el resto

                hilos[i] = new Thread(() => ContarEnRango(inicio, fin, numero1, numero2));
                hilos[i].Start();
            }

            foreach (var hilo in hilos)
                hilo.Join();
        }

        static void ContarEnRango(int inicio, int fin, int numero1, int numero2)
        {
            int contadorLocal = 0;

            for (int i = inicio; i < fin; i++)
            {
                if (vector[i] == numero1 || vector[i] == numero2)
                {
                    contadorLocal++;
                }
            }

            lock (_object)
            {
                aparacionesMultihilo += contadorLocal;
            }
        }

        static void MostrarLinea(TextWriter stream, string numHilosCabecera, string ticksCabecera, string resultadoCabecera)
        {
            stream.WriteLine("{0};{1};{2}", numHilosCabecera, ticksCabecera, resultadoCabecera);
        }
        static void MostrarLinea(TextWriter stream, int numHilos, long ticks, double resultado)
        {
            stream.WriteLine("{0};{1:N0};{2:N2}", numHilos, ticks, resultado);
        }

        static void ContarSecuencialAparaciones(short numero)
        {
            for (int i = 0; i < vector.Length; i++)
            {
                if (vector[i] == numero)
                {
                    aparicionesSecuencial++;   
                }
            }
        }

        static void ContarAparicionesNumeroEnVector(object? numero)
        {
            int buscado = (int)numero;
            //object o = new object(); --> Estaría mal porque cada hilo tiene su propio objeto y la idea es que
            // se trabaje sobre el mismo objeto
            for (int i = 0; i < vector.Length; i++)
            {
                if (vector[i] == buscado)
                {
                    // Sección crítica de código
                    // ¿Qué hace lock?
                    lock (_object) // Hace que el proximo hilo espere hasta que se salga de esta parte
                    {
                        aparacionesMultihilo++;
                    }
                    // Como regla básica, es necesario bloquear cualquier operación de escritura.
                    // Incluyendo los casos aparentemente más simples, como el de modificar/incrementar el valor de una variable.
                    // ¡REPASAD EN LA TEORÍA QUÉ OPERACIONES SON!
                }
            }
        }

        static void ContarLock(int numero)
        {
            int contadorLocal = 0;
            for (int i = 0; i < vector.Length; i++)
            {
                if (vector[i] == numero)
                {
                    contadorLocal++;
                }
            }
            lock (_object)
            {
                aparacionesMultihilo += contadorLocal;
            }
        }



        public static short[] CrearVectorAleatorio(int numElementos, short menor, short mayor)
        {
            short[] vector = new short[numElementos];
            Random random = new Random();
            for (int i = 0; i < numElementos; i++)
                vector[i] = (short)random.Next(menor, mayor + 1);
            return vector;
        }
    }
}
