﻿using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Simuladores
{
    public class SimuladorTiempo
    {
        private DateTime _fecha;
        private Estaciones _estacion;
        private Random random = new Random();

        public SimuladorTiempo()
        {
            _fecha = System.DateTime.Now;
            _estacion = Estaciones.Invierno;
        }

        public void AvanzarDias()
        {
            _fecha = _fecha.AddDays(random.Next(2, 12));
            CalcularEstacion();
        }
        public void AvanzarMeses()
        {
            _fecha = _fecha.AddMonths(random.Next(1, 4));
            CalcularEstacion();
        }
        public void CalcularEstacion()
        {
            if(_fecha.Month >= 2 || _fecha.Month <= 4)
            {
                _estacion = Estaciones.Primavera;
            } 
            else if(_fecha.Month >= 5 || _fecha.Month <= 7)
            {
                _estacion = Estaciones.Verano;
            }
            else if(_fecha.Month >= 8 || _fecha.Month <= 10)
            {
                _estacion = Estaciones.Otoño;
            }
            else
            {
                _estacion = Estaciones.Invierno;
            }
        }
        public override string ToString()
        {
            return $"{_fecha.ToString()} {_estacion.ToString()}";
        }
    }

    public enum Estaciones
    {
        Primavera, Verano, Otoño, Invierno
    }
}
