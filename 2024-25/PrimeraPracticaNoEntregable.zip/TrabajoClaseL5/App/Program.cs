﻿namespace App
{
    using Simuladores;
    using static System.Runtime.InteropServices.JavaScript.JSType;

    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    public class Cultivo()
    {
        private Estaciones cosecha;
        private int ritmoCrecimiento;
        private int crecimiento;
        private int cantidad;
        private bool muerto;
        private string identificador;
        Random random = new Random();

        //public Cultivo()
        //{
        //    cosecha = Estaciones.Invierno;
        //    ritmoCrecimiento = 0;
        //    crecimiento = 0;
        //    cantidad = 0;
        //    muerto = false;
        //    identificador = string.Empty;
        //}

        public void Regar(Estaciones _estacion)
        {
            if (!muerto)
            {
                crecimiento += ritmoCrecimiento;
            }
        }

        private int Cosechar(Estaciones _estacion)
        {
            if (muerto)
            {
                return 0;
            } 
            else if(_estacion == cosecha)
            {
                return random.Next(cantidad*2, (cantidad*5) + 1);
            } 
            else if(_estacion != cosecha)
            {
                return random.Next(cantidad, (cantidad * 2) + 1);
            }
            else
            {
                return random.Next(0, (cantidad * 2) + 1);
            }
        }

        private string ToString()
        {
            return $"{ritmoCrecimiento.ToString()} {crecimiento.ToString()} ({cantidad.ToString()} ({muerto.ToString()}) ({identificador.ToString()})";
        }
    }
}
