﻿using Modelo;

namespace _01ExtensoresLinq
{
    class Program
    {
        static void Main()
        {

            IEnumerable<int> valores = Enumerable.Range(1, 9);

            Console.WriteLine("Colecciones de enteros.");

            //Uso de métodos extensores
            //Map transforma una secuencia de <T>s en una secuencia de <Q>s.
            valores.Map(n => n * n).ForEach(Console.WriteLine);
            Console.WriteLine();

            valores.Map(n => n * n).Map(n => n / 2.0).ForEach(Console.WriteLine);
            Console.WriteLine();

            valores.Map(n => new Angulo(n))
                .Map(a => a.Grados)
                .ForEach(Console.WriteLine); 

            Console.WriteLine();

            Console.WriteLine("\nColecciones de Personas.");

            var personas = Factoria.CrearPersonas();

            var nombres = personas.Map(p => p.Nombre);
            nombres.ForEach(Console.WriteLine);
            Console.WriteLine();

            var iniciales = personas.Map(p => p.Nombre).Map(cadena => cadena[0]);
            iniciales.ForEach(Console.WriteLine);
            Console.WriteLine();
            personas.Map(p => p.Nif + "\t" + p.Nombre + "\t" + p.Apellido).ForEach(Console.WriteLine);


            //¿Qué estamos haciendo aquí?
            var info = personas.Map(p => new
                {
                    Nombre = p.Nombre,
                    Dni = p.Nif
                }
            );

            info.ForEach(Console.WriteLine);





            //Método ZIP de Linq: Combina dos secuencias:

            var combinación = valores.Zip(personas.Map(p => p.Nombre));
            combinación.Map(c => c.First + " : " + c.Second).ForEach(Console.WriteLine);


            /*
             * Ejercicio: Implementa una versión perezosa del Map.
             */

            /* EJERCICIO: Implementa el método Zip de LINQ:
             * - Colecciones potecialmente infinitas.
             * - Trabajará con tuplas .
             * */

        }
    }
}
