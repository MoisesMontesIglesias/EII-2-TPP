﻿using SimuladorLista;
namespace Main
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Lista list = new Lista();
            list.anadir(1);
            Console.WriteLine(list.getElemento(4));
            list.anadir(3);
            Console.WriteLine(list.getNumElems());
            Console.WriteLine(list.getElemento(3));
            list.anadir(4);
            Console.WriteLine(list.getNumElems());
            Console.WriteLine(list.borrar(2));
            Console.WriteLine(list.borrar(3));
            Console.WriteLine(list.getNumElems());
            Console.WriteLine(list.getElemento(1));
            Console.WriteLine(list.getElemento(3));
            Console.WriteLine(list.getNumElems());
        }
    }
}