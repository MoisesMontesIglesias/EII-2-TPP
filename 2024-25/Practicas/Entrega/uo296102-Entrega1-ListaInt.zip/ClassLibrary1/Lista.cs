﻿namespace SimuladorLista
{
    public class NodoInt
    {
        public int valor { get; set; }
        public NodoInt? Siguiente { get; set; }
        public NodoInt(int valor)
        {
            this.valor = valor;
            Siguiente = null;
        }
    }

    public class Lista
    {
        private NodoInt? head;
        private int numeroElementos;
        public Lista()
        {
            head = null;
            numeroElementos = 0;
        }

        public int getNumElems()
        {
            return numeroElementos;
        }

        public void anadir(int valor)
        {
            if(head == null)
            {
                head = new NodoInt(valor);
            }
            else
            {
                NodoInt actual = head;
                while(actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = new NodoInt(valor);
            }  
            numeroElementos++;
            
        }

        public bool borrar(int valor)
        {
            if(head == null)
            {
                return false;
            }
            else if (head.valor == valor)
            {
                head = head.Siguiente;
                numeroElementos--;
                return true;
            }
            else
            {
                NodoInt actual = head;
                while (actual.Siguiente != null && actual.Siguiente.valor != valor)
                {
                    actual = actual.Siguiente;
                }
                if(actual.Siguiente == null)
                {
                    return false;
                }
                else
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    numeroElementos--;
                    return true;
                }
            }
        }

        public int? getElemento(int pos)
        {
            if(pos < 0 || pos >= numeroElementos)
            {
                return null;
            }
            NodoInt? actual = head;
            for(int i = 0; i < pos; i++)
            {
                actual = actual?.Siguiente;
            }
            return actual?.valor;
        }
    }
}