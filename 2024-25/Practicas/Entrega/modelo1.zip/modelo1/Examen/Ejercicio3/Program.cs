﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Examen_parcial_2
{
    internal class Program
    {
        private const int MAX = 1_000_000;
        private const int NTHREADS = 4;
        private static object consoleMonitor = new object();

        static void Main(string[] args)
        {
            var numbers = new Queue<uint>();
            for (uint i = 0; i < MAX; i++)
            {
                numbers.Enqueue(i);
            }
            var primes = new List<uint>();


            var treads = new List<Thread>();
            var name = "";
            for (int i = 0; i < NTHREADS; i++)
            {
                name = $"Worker {i + 1}";
                var thread = new Thread(() =>
                {
                    while (true)
                    {
                        uint number = 0;
                        if (numbers.Count == 0)
                        {
                            lock (consoleMonitor)
                                Console.WriteLine($"  {name} finished");
                            break;
                        }
                        number = numbers.Dequeue();
                        if (IsPrime(number))
                        {
                            lock (primes)
                            {
                                primes.Add(number);
                            }
                        }
                    }
                });
                treads.Add(thread);
                thread.Start();
                lock (consoleMonitor)
                    Console.WriteLine($"{name} started");
            }

            while (true)
            {
                lock (numbers)
                {
                    if (numbers.Count == 0) break;
                    lock (consoleMonitor)
                        Console.WriteLine($"Numbers left: {numbers.Count}");
                }
                Thread.Sleep(100);
            }

            Console.WriteLine($"Primes found: {primes.Count}");
        }

        private static bool IsPrime(uint number)
        {
            if (number < 2) return false;
            for (uint i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }
    }
}