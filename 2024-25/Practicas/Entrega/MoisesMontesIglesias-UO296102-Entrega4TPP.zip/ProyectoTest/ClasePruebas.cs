﻿namespace ProyectoTest
{
    [TestClass]
    public sealed class ClasePruebas
    {
        [TestMethod]
        public void PruebasListaYDiccionario()
        {
            IList<int> lista = new List<int>();

            // 1. Añadir elementos
            lista.Add(10);
            lista.Add(20);
            lista.Add(30);
            lista.Add(20);

            // 2. Conocer el número de elementos
            Assert.AreEqual(4, lista.Count);

            // 3. Obtener y reescribir el elemento de la posición n-ésima
            Assert.AreEqual(20, lista[1]);
            lista[1] = 25;
            Assert.AreEqual(25, lista[1]);

            // 4. Saber si un elemento está o no en el vector
            Assert.IsTrue(lista.Contains(30));
            Assert.IsFalse(lista.Contains(100));

            // 5. Conocer el primer índice de un elemento dado
            Assert.AreEqual(3, lista.IndexOf(20));

            // 6. Borrar la primera aparición de un elemento dado
            lista.Remove(20);
            Assert.IsFalse(lista.Contains(20));
            Assert.AreEqual(3, lista.Count);
            lista.Remove(100);
            Assert.AreEqual(3, lista.Count);

            // 7. Iteración mediante un foreach
            Console.WriteLine("Elementos en la lista:");
            foreach (var objeto in lista)
            {
                Console.WriteLine(objeto);
            }

            IDictionary<string, int> diccionario = new Dictionary<string, int>();

            // 1. Añadir elementos con clave y valor dados
            diccionario.Add("uno", 1);
            diccionario.Add("dos", 2);
            diccionario.Add("tres", 3);

            // 2. Conocer el número de pares de la colección
            Assert.AreEqual(3, diccionario.Count);

            // 3. Obtener y reescribir el valor para una clave dada
            Assert.AreEqual(2, diccionario["dos"]);
            diccionario["dos"] = 22;
            Assert.AreEqual(22, diccionario["dos"]);

            // 4. Saber si una clave está o no en la colección
            Assert.IsTrue(diccionario.ContainsKey("tres"));

            // 5. Borrar, cuando exista, el elemento de la colección pasando su clave
            diccionario.Remove("uno");
            Assert.IsFalse(diccionario.ContainsKey("uno"));
            Assert.AreEqual(2, diccionario.Count);
            diccionario.Remove("cuatro");
            Assert.AreEqual(2, diccionario.Count);

            // 6. Iteración mediante un foreach
            Console.WriteLine("Elementos en el diccionario:");
            foreach (var objeto in diccionario)
            {
                Console.WriteLine($"{objeto.Key}: {objeto.Value}");
            }
        }
    }
}
