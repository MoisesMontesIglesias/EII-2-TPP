﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorLista
{
    public class ListaGenerica<T> : IEnumerable<T>
    {
        private int numElementos;
        private Nodo? head;
        private IteradorLista<T> iterador = new IteradorLista<T>();

        public ListaGenerica() {
            numElementos = 0;
            head = null;
        }

        public void Añadir(T? valor)
        {
            Nodo nuevoNodo = new Nodo(valor, null);
            if (head == null)
            {
                head = nuevoNodo;
            }
            else
            {
                Nodo posUltimo = GetNodoAt(numElementos - 1);
            }
        }

        public void Borrar()
        {

        }

        public IEnumerator<T> GetEnumerator()
        {
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public int GetNumElems()
        {
            throw new NotImplementedException();
        }

        public Nodo GetNodoAt(int contador)
        {
            throw new NotImplementedException();
        }
    }

    public class Nodo<T>
    {
        public T valor { get; set; }
        public Nodo? Siguiente { get; set; }
        public Nodo(T valor, Nodo siguiente)
        {
            this.valor = valor;
            this.Siguiente = siguiente;
        }
    }
    public class IteradorLista<T> : IEnumerator<T>
    {

        private int contador;
        private ListaGenerica<T> lista = new ListaGenerica<T>();

        public IteradorLista()
        {
            contador = 0;
        }

        public T Current()
        {
            return lista.GetNodoAt(contador);
        }

        object IEnumerator.Current => throw new NotImplementedException();

        T IEnumerator<T>.Current => throw new NotImplementedException();

        public void Dispose()
        {
        }

        public bool MoveNext()
        {
            contador++;
            if(contador > lista.GetNumElems())
            {
                return false;
            }
            return true;
        }

        public void Reset()
        {
            contador = -1;
        }
    }
}
