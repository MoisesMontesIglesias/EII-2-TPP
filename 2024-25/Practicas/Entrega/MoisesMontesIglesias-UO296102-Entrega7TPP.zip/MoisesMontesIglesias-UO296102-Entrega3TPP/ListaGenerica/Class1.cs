﻿namespace ListaGenerica
{
    public class Class1
    {

    }
}
