﻿using System;
using System.Collections;

namespace SimuladorListaGenerica
{
    public class ListaGenerica<T> : IEnumerable<T>
    {
        private int numElementos;
        private Nodo? head;
        private IteradorDeLista<T> iterador;

        public ListaGenerica() {
            numElementos = 0;
            head = null;
        }

        public void Añadir(T valor)
        {
            Nodo? nuevoNodo = new Nodo(valor);
            if (head == null)
            {
                head = nuevoNodo;
            }
            else
            {
                Nodo? posUltimo = GetNodoAt(numElementos - 1);
                posUltimo.Siguiente = nuevoNodo;
            }
            numElementos++;
        }

        public bool Borrar(T nodo)
        {
            if (numElementos == 0)
            {
                return false;
            }
            int posicion = GetPosicionNodo(nodo);
            if (posicion != -1)
            {
                Nodo? nodoAnterior = GetNodoAt(posicion - 1);
                nodoAnterior.Siguiente = nodoAnterior?.Siguiente?.Siguiente;
                numElementos--;
                return true;
            }
            return false;
        }

        public int GetPosicionNodo(T nodo)
        {
            Nodo? NodoCopia = head;
            int posicion = 0;
            for (int i = 0; i < numElementos; i++)
            {
                if (nodo == null)
                {
                    if (NodoCopia == null)
                    {
                        return posicion;
                    }
                }
                else if (NodoCopia != null && NodoCopia.valor.Equals(nodo))
                {
                    return posicion;
                }
                else
                {
                    NodoCopia = NodoCopia?.Siguiente;
                    posicion++;
                }
            }
            return -1;
        }

        public IEnumerator<T> GetEnumerator()
        {
            return iterador;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return iterador;
        }

        public int GetNumElems()
        {
            return numElementos;
        }
        private Nodo? GetNodoAt(int contador)
        {
            if (contador < 0 || contador > numElementos)
            {
                throw new ArgumentOutOfRangeException("Valor fuera de rango");
            }
            Nodo? actual = head;
            for (int i = 0; i < contador; i++)
            {
                actual = actual?.Siguiente;
            }
            return actual;
        }
        public override string ToString()
        {
            String path = "";
            Nodo? actual = head;
            for (int i = 0; i < numElementos; i++)
            {
                path += Convert.ToString(actual.valor) + "; ";
                actual = actual?.Siguiente;
            }
            return path;
        }

        public bool Contiene(T nodo)
        {
            Nodo? copia = head;
            for(int i = 0; i < numElementos; i++)
            {
                if(nodo == null)
                {
                    if(copia == null)
                    {
                        return true;
                    }
                }
                else
                {
                    if (copia != null && nodo.Equals(copia.valor)){
                        return true;
                    }
                }
            }
            return false;
        }

        public override bool Equals(Object? objeto)
        {
            if (objeto == null || objeto.GetType() != typeof(ListaGenerica<T>))
            {
                return false;
            }
            ListaGenerica<T>? lista = objeto as ListaGenerica<T>;
            if(lista == null)
            {
                return false;
            }
            return ((this.head == null && lista.head == null) ||
                (this.head != null && this.head != null && this.head.Equals(lista.head))) 
                && this.numElementos.Equals(lista.numElementos);

        }

        internal class Nodo
        {
            public T valor { get; set; }
            public Nodo? Siguiente { get; set; }
            public Nodo(T valor)
            {
                this.valor = valor;
                this.Siguiente = null;
            }
        }
        public class IteradorDeLista<T> : IEnumerator<T>
        {

            private int posicion;
            private ListaGenerica<T> lista;

            public IteradorDeLista(ListaGenerica<T> lista)
            {
                this.lista = lista;
                posicion = 0;
            }

            public T Current()
            {
                return lista.GetNodoAt(posicion).valor;
            }

            object IEnumerator.Current => throw new NotImplementedException();

            T IEnumerator<T>.Current => throw new NotImplementedException();

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                posicion++;
                if (posicion > lista.GetNumElems())
                {
                    return false;
                }
                return true;
            }

            public void Reset()
            {
                posicion = -1;
            }
        }

        public static T? Buscar<T>(IEnumerable<T> lista, Predicate<T> funcion)
        {
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    return elemento;
                }
            }
            return default(T);
        }

        public static IEnumerable<T> Filtrar<T>(IEnumerable<T> lista, Predicate<T> funcion, IList<T> nuevaLista)
        {
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    nuevaLista.Add((T)elemento);
                }
            }
            return nuevaLista;
        }

        public static T1? Reducir<T1, T2>(IEnumerable<T2> lista, Func<T1, T2, T1> funcion)
        {
            T1? valor = default(T1);
            foreach (T2 elemento in lista)
            {
                valor = funcion(valor, elemento);
            }
            return valor;
        }

        public static T1? Invertir<T1, T2>(IEnumerable<T2> lista, Func<T1, T2, T1> funcion)
        {
            T1? valor = default(T1);
            foreach (T2 elemento in lista.Reverse())
            {
                valor = funcion(valor, elemento);
            }
            return valor;
        }

        public static IEnumerable<Q> Map<T, Q>(IEnumerable<T> enumerable, Func<T, Q> func)
        {
            IList<Q> lista = new List<Q>();
            foreach (T actual in enumerable)
                lista.Add(func(actual));
            return lista;
        }

        public static void ForEach<T>(IEnumerable<T> enumerable, Action<T> action)
        {
            foreach (T item in enumerable)
            {
                action(item);
            }
        }

        public override int GetHashCode()
        {
            throw new NotImplementedException();
        }
    }
}
