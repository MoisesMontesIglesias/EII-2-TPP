﻿

namespace Modelo
{
    public static class Funciones
    {


        /// <summary>
        /// Devuelve el resultado de a + b
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int Sumar(int a, int b)
        {
            return a + b;
        }


        /// <summary>
        /// Devuelve el módulo de la operación a/b
        /// Devuelve 0 si b = 0
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int Modulo(int a, int b)
        {
            if (b == 0)
                return 0;
            return a % b;
        }

        /// <summary>
        /// Devuelve el producto de dos enteros.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static int Multiplicar(int a, int b)
        {
            return a * b;
        }



        public static void Imprime()
        {
            Console.WriteLine("Imprimiendo por pantalla");
        }

        public static T? Buscar<T>(IEnumerable<T> lista, Predicate<T> funcion)
        {
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    return elemento;
                }
            }
            return default(T);
        }

        public static IEnumerable<T> Filtrar<T>(IEnumerable<T> lista, Predicate<T> funcion)
        {
            IList<T> nuevaLista = new List<T>();
            foreach (T elemento in lista)
            {
                if (funcion(elemento))
                {
                    nuevaLista.Add((T)elemento);
                }
            }
            return nuevaLista;
        }

        public static T1? Reducir<T1, T2>(IEnumerable<T2> lista, Func<T1, T2, T1> funcion)
        {
            T1? valor = default(T1);
            foreach (T2 elemento in lista)
            {
                valor = funcion(valor, elemento);
            }
            return valor;
        }
    }
}
