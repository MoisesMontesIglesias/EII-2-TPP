﻿using SimuladorLista;
namespace Main
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Lista list = new Lista();
            list.Anadir(1);
            Console.WriteLine(list.GetElemento(4));
            list.Anadir(3);
            Console.WriteLine(list.GetNumElems());
            Console.WriteLine(list.GetElemento(3));
            list.Anadir(4);
            Console.WriteLine(list.GetNumElems());
            Console.WriteLine(list.Borrar(2));
            Console.WriteLine(list.Borrar(3));
            Console.WriteLine(list.GetNumElems());
            Console.WriteLine(list.GetElemento(1));
            Console.WriteLine(list.GetElemento(3));
            Console.WriteLine(list.GetNumElems());
        }
    }
}