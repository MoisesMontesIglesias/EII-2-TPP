﻿using SimuladorLista;
using Modelo;
namespace ClaseTest
{
    [TestClass]
    public sealed class PruebasTest
    {
        [TestMethod]
        public void MetodoPruebas()
        {
            Lista list = new Lista();
            Persona persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Persona persona2 = new Persona("Juan", "Alvarez", "1234");
            Persona persona3 = new Persona("Maria", "Jimenez", "2334");
            list.Anadir(persona1);
            Assert.AreEqual(1, list.GetNumElems());
            list.Anadir(persona3);
            Assert.AreEqual(2, list.GetNumElems());
            list.Anadir(new Persona("Jorge", "Montes", "9743"));
            Assert.AreEqual(3, list.GetNumElems());
            list.Anadir(new Persona("Ana", "Iglesias", "3456"));
            Assert.AreEqual(4, list.GetNumElems());
            list.Anadir(new Persona("Pedro", "Gonzalez", "3124"));
            Assert.AreEqual(5, list.GetNumElems());
            Assert.AreEqual(true, list.Borrar(persona1));
            Assert.AreEqual(4, list.GetNumElems());
            Assert.AreEqual(false, list.Borrar(persona2));
            Assert.AreEqual(4, list.GetNumElems());
            Assert.AreEqual(true, list.Contiene(persona3));
            Assert.AreEqual(false, list.Contiene(new Persona("Manuel", "Jimenez", "2334")));
            Assert.AreEqual(persona3, list.GetElemento(0));
        }
    }
}
