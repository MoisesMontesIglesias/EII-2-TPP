﻿using System.Drawing;
using System.Xml.Linq;

namespace SimuladorLista
{
    public class Nodo
    {
        public Object valor { get; set; }
        public Nodo? Siguiente { get; set; }
        public Nodo(Object valor)
        {
            this.valor = valor;
            Siguiente = null;
        }
    }

    public class Lista
    {
        private Nodo? head;
        private int numeroElementos;
        public Lista()
        {
            head = null;
            numeroElementos = 0;
        }

        public int GetNumElems()
        {
            return numeroElementos;
        }

        public void Anadir(Object valor)
        {
            if (head == null)
            {
                head = new Nodo(valor);
            }
            else
            {
                Nodo actual = head;
                while (actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = new Nodo(valor);
            }
            numeroElementos++;
        }

        public bool Borrar(Object valor)
        {
            if (head == null)
            {
                return false;
            }
            else if (head.valor.Equals(valor))
            {
                head = head.Siguiente;
                numeroElementos--;
                return true;
            }
            else
            {
                Nodo actual = head;
                while (actual.Siguiente != null && actual.Siguiente.valor != valor)
                {
                    actual = actual.Siguiente;
                }
                if (actual.Siguiente == null)
                {
                    return false;
                }
                else
                {
                    actual.Siguiente = actual.Siguiente.Siguiente;
                    numeroElementos--;
                    return true;
                }
            }
        }

        public Object? GetElemento(int pos)
        {
            if (pos < 0 || pos >= numeroElementos)
            {
                return null;
            }
            Nodo? actual = head;
            for (int i = 0; i < pos; i++)
            {
                actual = actual?.Siguiente;
            }
            return actual?.valor;
        }

        public bool? Contiene(Object valor)
        {
            Nodo? actual = head;
            while (actual != null)
            {
                if (actual.valor.Equals(valor))
                {
                    return true;
                }
                actual = actual?.Siguiente;
            }
            return false;
        }
        override public String ToString()
        {
            String cadena = String.Empty;
            Nodo? actual = head;
            for (int i = 0; i < GetNumElems(); i++)
            {
                cadena += actual?.ToString() + "; ";
                actual = actual?.Siguiente;
            }
            return cadena;
        }
    }
}