﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace SimuladorLista
{
    public class Pila
    {
        private Lista lista = new Lista();
        private uint numeroMaxElementos;

        public Pila(uint numeroMaxElementos)
        {
            this.numeroMaxElementos = numeroMaxElementos;
        }

        public uint NumeroElementosMaximo()
        {
            return numeroMaxElementos;
        }

        public int NumeroElementosEnLista()
        {
            return lista.GetNumElems();
        }

        public void Push(Object valor)
        {
#if DEBUG
            //Estado consistente al comienzo del método
            Invariante();
            int cantidadPrevia = NumeroElementosEnLista();
#endif
            //Precondiciones del método
            if (EstaLlena())
            {
                throw new ArgumentOutOfRangeException("La pila está llena");
            }
            //Método
            lista.Anadir(valor);
#if DEBUG
            //Postcondicones del método
            Debug.Assert(NumeroElementosEnLista() == cantidadPrevia + 1, "Fallo en postcondicion de Push en la Pila, no subio el numero de elementos");
            Console.WriteLine(valor);
            Console.WriteLine(lista.GetElemento(lista.GetNumElems()));
            //Debug.Assert(valor == lista.GetElemento(lista.GetNumElems()) || valor.Equals(lista.GetElemento(lista.GetNumElems())), "Fallo en postcondicion de Push en la Pila, no se añadió al final");
            Invariante();
#endif
        }

        public Object? Pop()
        {
#if DEBUG
            //Estado consistente al comienzo del método
            Invariante();
            int cantidadPrevia = NumeroElementosEnLista();
            Object? objetoPrevio = lista.GetElemento(lista.GetNumElems());
#endif
            //Precondiciones del método
            if (EstaVacia())
            {
                throw new ArgumentOutOfRangeException("La pila está vacía");
            }
            //Método
            Object? objeto = lista.BorrarIndexOf(lista.GetNumElems());

#if DEBUG
            //Postcondicones del método
            Debug.Assert(NumeroElementosEnLista() == cantidadPrevia - 1, "Fallo en postcondicion de Pop en la Pila, no cambio el número de elementos");
            //Debug.Assert(Equals(objetoPrevio,objeto), "Fallo en postcondicion de Pop en la Pila, no se añadió el objeto");
            Invariante();
#endif
            return objeto;
        }

        public bool EstaVacia()
        {
#if DEBUG
            Invariante();
#endif
            bool valor = false;
            if(lista.GetNumElems() == 0)
            {
                valor = true;
            }
#if DEBUG
            Invariante();
#endif
            return valor;
        }

        public bool EstaLlena()
        {
#if DEBUG
            Invariante();
#endif
            bool valor = false;
            if (numeroMaxElementos == lista.GetNumElems())
            {
                valor = true;
            }
#if DEBUG
            Invariante();
#endif
            return valor;
        }

        private void Invariante()
        {
            Debug.Assert(numeroMaxElementos >= 0 && lista != null, "Error en la invariante");
        }
    }
}
