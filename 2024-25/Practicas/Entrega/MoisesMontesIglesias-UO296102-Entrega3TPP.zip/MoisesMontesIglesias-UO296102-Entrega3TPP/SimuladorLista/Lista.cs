﻿using System.Drawing;
using System.Xml.Linq;

namespace SimuladorLista
{
    public class Nodo
    {
        public Object valor { get; set; }
        public Nodo? Siguiente { get; set; }
        public Nodo(Object valor)
        {
            this.valor = valor;
            Siguiente = null;
        }
    }

    public class Lista
    {
        private Nodo? head;
        private int numeroElementos;
        public Lista()
        {
            head = null;
            numeroElementos = 0;
        }

        public int GetNumElems()
        {
            return numeroElementos;
        }

        public void Anadir(Object valor)
        {
            if (head == null)
            {
                head = new Nodo(valor);
            }
            else
            {
                Nodo? actual = head;
                while (actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = new Nodo(valor);
            }
            numeroElementos++;
        }

        public bool Borrar(Object? valor)
        {
            if (numeroElementos == 0)
            {
                return false;
            }
            else if (Equals(head?.valor, valor))
            {
                head = head?.Siguiente;
                numeroElementos--;
                return true;
            }
            else
            {
                Nodo? actual = head;
                int contador = 0;
                while (!Equals(actual?.Siguiente?.valor,valor) && contador <= numeroElementos)
                {
                    actual = actual?.Siguiente;
                    contador++;
                }
                if (contador > numeroElementos)
                {
                    return false;
                }
                else
                {
                    actual = actual?.Siguiente;
                    numeroElementos--;
                    return true;
                }
            }
        }

        public Object? BorrarIndexOf(int indice)
        {
            if (indice < 0 || indice > numeroElementos)
            {
                throw new Exception("Indice incorrecto");
            }
            else if(numeroElementos == 0)
            {
                throw new Exception("La lista está vacía");
            }
            else if(indice == 0)
            {
                Nodo? salvaGuarda = head;
                head = head?.Siguiente;
                numeroElementos--;
                return salvaGuarda?.valor;
            }
            else
            {
                int contador = 0;
                Nodo? actual = head;
                while (contador < indice - 2)
                {
                    actual = actual?.Siguiente;
                    contador++;
                }
                Nodo? salvaGuarda = actual?.Siguiente;
                actual = actual?.Siguiente;
                numeroElementos--;
                return salvaGuarda?.valor;
            }
        }

        public Object? GetElemento(int pos)
        {
            if (pos < 0 || pos >= numeroElementos)
            {
                return null;
            }
            Nodo? actual = head;
            for (int i = 0; i < pos; i++)
            {
                actual = actual?.Siguiente;
            }
            return actual?.valor;
        }

        public bool Contiene(Object? valor)
        {
            Nodo? actual = head;
            int contador = 0;
            while (contador <= numeroElementos)
            {
                if (Equals(actual?.valor,valor))
                {
                    return true;
                }
                actual = actual?.Siguiente;
                contador++;
            }
            return false;
        }
        override public String ToString()
        {
            String cadena = String.Empty;
            Nodo? actual = head;
            for (int i = 0; i < GetNumElems(); i++)
            {
                cadena += actual?.ToString() + "; ";
                actual = actual?.Siguiente;
            }
            return cadena;
        }
    }
}