﻿using SimuladorLista;
using Modelo;
namespace ClaseTest
{
    [TestClass]
    public sealed class PruebasTest
    {

        [TestMethod]
        public void MetodoPruebasListaAgregar()
        {
            Lista? list = new Lista();
            Persona persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Persona persona2 = new Persona("Juan", "Alvarez", "1234");
            Persona persona3 = new Persona("Maria", "Jimenez", "2334");
            list.Anadir(persona1);
            Assert.AreEqual(1, list.GetNumElems());
            list.Anadir(persona2);
            Assert.AreEqual(2, list.GetNumElems());
            list.Anadir(persona2);
            Assert.AreEqual(3, list.GetNumElems());
            list.Anadir(persona3);
            Assert.AreEqual(4, list.GetNumElems());
            list.Anadir(null);
            Assert.AreEqual(5, list.GetNumElems());
        }

        [TestMethod]
        public void MetodoPruebasListaBorrar()
        {
            Lista? list = new Lista();
            Persona persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Persona persona2 = new Persona("Juan", "Alvarez", "1234");
            Persona persona3 = new Persona("Maria", "Jimenez", "2334");
            list.Anadir(persona1);
            list.Anadir(persona2);
            list.Anadir(persona2);
            list.Anadir(persona3);
            list.Anadir(null);
            Assert.AreEqual(5, list.GetNumElems());
            Assert.AreEqual(true, list.Borrar(persona1));
            Assert.AreEqual(4, list.GetNumElems());
            Assert.AreEqual(true, list.Borrar(persona2));
            Assert.AreEqual(3, list.GetNumElems());
            Assert.AreEqual(false, list.Borrar(persona1));
            Assert.AreEqual(3, list.GetNumElems());
        }

        [TestMethod]
        public void MetodoPruebasListaContiene()
        {
            Lista? list = new Lista();
            Persona persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Persona persona2 = new Persona("Juan", "Alvarez", "1234");
            Persona persona3 = new Persona("Maria", "Jimenez", "2334");
            list.Anadir(persona1);
            list.Anadir(persona2);
            list.Anadir(persona2);
            list.Anadir(persona3);
            list.Anadir(null);
            Assert.AreEqual(true, list.Contiene(persona1));
            Assert.AreEqual(true, list.Contiene(persona2));
            Assert.AreEqual(true, list.Borrar(persona1));
            Assert.AreEqual(4, list.GetNumElems());
            Assert.AreEqual(false, list.Contiene(persona1));
        }

        [TestMethod]
        public void MetodoPruebasPilaPush()
        {
            Pila pila = new Pila(5); 
            Persona persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Persona persona2 = new Persona("Juan", "Alvarez", "1234");
            Persona persona3 = new Persona("Maria", "Jimenez", "2334");
            pila.Push(persona1);
            Assert.AreEqual(1, pila.NumeroElementosEnLista());
            pila.Push(persona3);
            Assert.AreEqual(2, pila.NumeroElementosEnLista());
            pila.Push(new Persona("Jorge", "Montes", "9743"));
            Assert.AreEqual(3, pila.NumeroElementosEnLista());
            pila.Push(new Persona("Ana", "Iglesias", "3456"));
            Assert.AreEqual(4, pila.NumeroElementosEnLista());
            pila.Push(new Persona("Pedro", "Gonzalez", "3124"));
            Assert.AreEqual(5, pila.NumeroElementosEnLista());
        }

        [TestMethod]
        public void MetodoPruebasPilaPop()
        {
            Pila pila = new Pila(5);
            Object persona1 = new Persona("Alvaro", "Alvarez", "1234");
            Object persona2 = new Persona("Juan", "Alvarez", "1234");
            Object persona3 = new Persona("Maria", "Jimenez", "2334");
            pila.Push(new Persona("Jorge", "Montes", "9743"));
            Assert.AreEqual(1, pila.NumeroElementosEnLista());
            pila.Push(new Persona("Ana", "Iglesias", "3456"));
            Assert.AreEqual(2, pila.NumeroElementosEnLista());
            pila.Push(new Persona("Pedro", "Gonzalez", "3124"));
            Assert.AreEqual(3, pila.NumeroElementosEnLista());
            pila.Push(persona1);
            Assert.AreEqual(4, pila.NumeroElementosEnLista());
            pila.Push(persona3);
            Assert.AreEqual(5, pila.NumeroElementosEnLista());
            Assert.AreEqual(persona3, pila.Pop());
            Assert.AreEqual(4, pila.NumeroElementosEnLista());
            Assert.AreEqual(persona1, pila.Pop());
            Assert.AreEqual(3, pila.NumeroElementosEnLista());
        }
    }
}
