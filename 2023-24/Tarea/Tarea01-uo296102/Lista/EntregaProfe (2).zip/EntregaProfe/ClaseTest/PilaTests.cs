
namespace Pruebas
{
    [TestClass]
    public class PilaTests
    {
        Pila pila = new Pila(6);
        Pila pilaTexto = new Pila(3);
        [TestMethod]
        public void inicializarLista()
        {
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            pila.Push(4);
            pila.Push(5);
            pila.Push(6);
        }

        [TestMethod]
        public void PruebaM�todoPushCorrecto()
        {
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsTrue(pila.EstaVac�a(), "La lista est� vac�a");
            Assert.AreEqual(0, pila.NumeroTotalElementos);
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            Assert.AreEqual(3, pila.NumeroTotalElementos);
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            pila.Push(4);
            pila.Push(5);
            pila.Push(6);
            Assert.AreEqual(6, pila.NumeroTotalElementos);
            Assert.IsTrue(pila.EstaLlena(), "La lista est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
        }

        [TestMethod]
        public void PruebaM�todoPushDatoNull()
        {
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            pila.Push(4);
            pila.Push(5);
            pila.Push(null);
            Assert.AreEqual(5, pila.NumeroTotalElementos, "No se a�adi� ning�n elemento");
        }

        [TestMethod]
        public void PruebaM�todoBorrarCorrecto()
        {
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsTrue(pila.EstaVac�a(), "La lista est� vac�a");
            Assert.AreEqual(0, pila.NumeroTotalElementos);
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            Assert.AreEqual(3, pila.NumeroTotalElementos);
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            Assert.AreEqual(3, pila.Pop(), "Se borra el �ltimo elemento");
            Assert.AreEqual(2, pila.NumeroTotalElementos);
            pila.Push(3);
            pila.Push(4);
            pila.Push(5);
            pila.Push(6);
            Assert.AreEqual(6, pila.NumeroTotalElementos);
            Assert.IsTrue(pila.EstaLlena(), "La lista est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            Assert.AreEqual(6, pila.Pop(), "Se borra el �ltimo elemento");
            Assert.AreEqual(5, pila.NumeroTotalElementos);
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
        }

        [TestMethod]
        public void PruebaM�todoBorrarDatoNull()
        {
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsTrue(pila.EstaVac�a(), "La lista est� vac�a");
            Assert.AreEqual(0, pila.NumeroTotalElementos);
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            Assert.AreEqual(3, pila.NumeroTotalElementos);
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            Assert.AreEqual(3, pila.Pop(), "No se borra ning�n elemento");
            Assert.AreEqual(2, pila.NumeroTotalElementos);
        }

        [TestMethod]
        public void PruebaM�todoBorrarDatoNoEncontrado()
        {
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsTrue(pila.EstaVac�a(), "La lista est� vac�a");
            Assert.AreEqual(0, pila.NumeroTotalElementos);
            pila.Push(1);
            pila.Push(2);
            pila.Push(3);
            Assert.AreEqual(3, pila.NumeroTotalElementos);
            Assert.IsFalse(pila.EstaLlena(), "La lista no est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            Assert.AreEqual(7, pila.Pop(), "Se borra el �ltimo elemento");
            Assert.AreEqual(3, pila.NumeroTotalElementos);
            pila.Push(3);
            pila.Push(4);
            pila.Push(5);
            pila.Push(6);
            Assert.AreEqual(6, pila.NumeroTotalElementos);
            Assert.IsTrue(pila.EstaLlena(), "La lista est� llena");
            Assert.IsFalse(pila.EstaVac�a(), "La lista no est� vac�a");
            Assert.AreEqual(19, pila.Pop(), "Se borra el �ltimo elemento");
            Assert.AreEqual(6, pila.NumeroTotalElementos);
            Assert.IsTrue(pila.EstaLlena(), "La lista est� llena");
        }

        [TestMethod]
        public void PruebaM�todoA�adirTexto()
        {
            pilaTexto.Push("Hola");
            pilaTexto.Push("mundo");
            pilaTexto.Push("!");
            Assert.AreEqual(3, pilaTexto.NumeroTotalElementos, "Se a�adieron los 3 elementos correctamente");
        }

        [TestMethod]
        public void PruebaM�todoBorrarTexto()
        {
            pilaTexto.Push("Hola");
            pilaTexto.Push("mundo");
            pilaTexto.Push("!");
            Assert.AreEqual(pilaTexto.Pop(), "!", "Se borr� el tercer elemento");
            Assert.AreNotEqual(pilaTexto.Pop(), "objeto", "Se borro el segundo elemento correctamente");
            Assert.AreEqual(1, pilaTexto.NumeroTotalElementos, "Se borro el tercer elemento correctamente");
        }
    }
}