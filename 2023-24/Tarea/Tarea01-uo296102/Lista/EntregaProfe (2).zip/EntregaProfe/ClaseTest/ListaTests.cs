
namespace Pruebas
{
    [TestClass]
    public class ListaPruebas
    {
        Lista lista = new Lista();
        Lista listaTexto = new Lista();
        [TestMethod]
        public void inicializarLista()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            listaTexto.A�adir("Hola");
            listaTexto.A�adir("mundo");
            listaTexto.A�adir("!");
        }

        [TestMethod]
        public void PruebaM�todoA�adirCorrecto()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            int nuevo = 7;
            lista.A�adir(nuevo);
            Assert.AreEqual(nuevo, lista.NumeroElementos, "Se a�adi� un nuevo elemento");
            lista.A�adir(8);
            Assert.AreEqual(8, lista.NumeroElementos, "Se a�adi� un nuevo elemento");
        }

        [TestMethod]
        public void PruebaM�todoA�adirDatoNull()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            lista.A�adir(null);
            Assert.AreEqual(6, lista.NumeroElementos, "No se a�adi� ning�n elemento");
        }

        [TestMethod]
        public void PruebaM�todoBorrarCorrecto()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            Assert.IsTrue(lista.Borrar(6), "Se borr� un elemento correctamente");
            Assert.IsTrue(lista.Borrar(4), "Se borro otro elemento");
            Assert.IsTrue(lista.Borrar(2), "Se borro otro elemento");
        }

        [TestMethod]
        public void PruebaM�todoBorrarDatoNull()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            Assert.IsFalse(lista.Borrar(null), "No se borr� ning�n elemento");
            Assert.AreEqual(6, lista.NumeroElementos, "El n�mero de elementos sigue siendo el mismo");
        }

        [TestMethod]
        public void PruebaM�todoBorrarDatoNoEncontrado()
        {
            lista.A�adir(1);
            lista.A�adir(2);
            lista.A�adir(3);
            lista.A�adir(4);
            lista.A�adir(5);
            lista.A�adir(6);
            Assert.IsFalse(lista.Borrar(17), "No se borr� ning�n elemento porque no se encontr�");
            Assert.IsFalse(lista.Borrar(10), "No se borr� ning�n elemento porque no se encontr�");
            Assert.IsFalse(lista.Borrar(1000), "No se borr� ning�n elemento porque no se encontr�");
            Assert.AreEqual(6, lista.NumeroElementos, "Ning�n elemento fue borrado");
        }

        [TestMethod]
        public void PruebaM�todoA�adirTexto()
        {
            listaTexto.A�adir("Hola");
            listaTexto.A�adir("mundo");
            listaTexto.A�adir("!");
            Assert.AreEqual(3, listaTexto.NumeroElementos, "Se a�adieron los 3 elementos correctamente");
        }

        [TestMethod]
        public void PruebaM�todoBorrarTexto()
        {
            listaTexto.A�adir("Hola");
            listaTexto.A�adir("mundo");
            listaTexto.A�adir("!");
            Assert.IsTrue(listaTexto.Borrar("!"), "Se borr� el tercer elemento");
            Assert.AreEqual(2, listaTexto.NumeroElementos, "Se borro el tercer elemento correctamente");
        }

        [TestMethod]
        public void PruebaM�todoContiene()
        {
            listaTexto.A�adir("Hola");
            listaTexto.A�adir("mundo");
            listaTexto.A�adir("!");
            Assert.IsTrue(listaTexto.Contiene("!"), "Si contiene el texto !");
            Assert.IsFalse(listaTexto.Contiene("HolaMundo"), "No contiene el texto HolaMundo");
        }

        [TestMethod]
        public void PruebaM�todoContieneNull()
        {
            listaTexto.A�adir("Hola");
            listaTexto.A�adir("mundo");
            listaTexto.A�adir("!");
            Assert.IsFalse(listaTexto.Contiene(null), "No contiene Null");
        }
    }
}