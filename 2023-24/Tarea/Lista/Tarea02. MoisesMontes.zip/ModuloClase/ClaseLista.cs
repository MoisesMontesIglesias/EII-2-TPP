﻿using System;

namespace ModuloClase
{   
    public class Nodo
    {
        public Object Objeto { get; set; }
        public Nodo Siguiente { get; set; }

        public Nodo(Object Objeto, Nodo Siguiente = null)
        {
            this.Objeto = Objeto;
            this.Siguiente = Siguiente;
        }
    }

    public class Lista
    {
        public Nodo Nodo { get; set; }
        private int numE;
        public int NumeroElementos { get { return numE; } }

        public Lista()
        {
            Nodo = null;
            numE = 0;
        }

        public Nodo GetNodoAt(int posicion) {
            Nodo CopiaNodo = Nodo;
            for (int i = 0; i < posicion; i++) {
                CopiaNodo = Nodo.Siguiente;
            }
            return CopiaNodo;
        }

        public void Añadir(Object Objeto)
        {
            if(Objeto == null)
            {
                Console.WriteLine("No puedes añadir un objeto null");
                return;
            }
            Nodo Nuevo = new Nodo(Objeto, null);
            if (Nodo == null)
            {
                Nodo = Nuevo;
            }
            else
            {
                Nodo ultimo = GetNodoAt(NumeroElementos - 1);
                ultimo.Siguiente = Nuevo;
            }
            numE++;
        }

        public bool Borrar(Object Objeto)
        {
            if (Objeto == null)
            {
                Console.WriteLine("No puedes añadir un objeto null");
                return false;
            }
            int posicion = GetPosNodo(Objeto);
            if (posicion != -1)
            {
                Nodo anterior = GetNodoAt(posicion - 1);
                anterior.Siguiente = anterior.Siguiente.Siguiente;
                numE--;
                return true;
            }
            return false;
        }

        public int GetPosNodo(Object Objeto)
        {
            Nodo CopiaNodo = Nodo;
            int contador = 0;
            for (int i = 0; i < NumeroElementos; i++)
            {
                if (CopiaNodo.Objeto.Equals(Objeto))
                {
                    return contador;
                }
                CopiaNodo = Nodo.Siguiente;
                contador++;
            }
            return -1;
        }

        public override String ToString()
        {
            String path = "";
            for (int i = 0; i < NumeroElementos; i++)
            {
                path += Convert.ToString(Nodo) + ";";
                Nodo = Nodo.Siguiente;
            }
            return path;
        }

        public bool Contiene(Object Objeto)
        {
            if (Objeto == null)
            {
                Console.WriteLine("No puedes añadir un objeto null");
                return false;
            }
            for (int i = 0; i < NumeroElementos; i++)
            {
                if (Nodo.Objeto.Equals(Objeto)){
                    return true;
                }
            }
            return false;
        }

        public void Vaciar()
        {
            Nodo = null;
            numE = 0;
        }

        public bool saberSiListaVacia()
        {
            if(NumeroElementos == 0)
            {
                return true;
            }
            return false;
        } 
    } 
}